#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int
}